# MotionKit

一个轻量、现代的前端动效库，同时支持 **CSS 类动画** 和 **Web Animations API**。

## 特性

- 🎨 **15+ 预设动画**：fade、slide、zoom、bounce、flip、shake、pulse、rotate 等
- 🔧 **双模式**：CSS 关键帧动画 + Web Animations API
- 🌳 **Tree-shaking**：按需引入，不打包多余代码
- 📘 **TypeScript**：完整的类型定义
- 📦 **零依赖**：纯原生实现

## 安装

```bash
npm install mk-motion
```

## 快速开始

### 方式一：CSS 类（推荐简单场景）

```html
<div class="mk-animated mk-slideInUp">Hello World</div>
```

```css
/* 自定义时长和缓动 */
.my-box {
  --mk-duration: 0.8s;
  --mk-easing: cubic-bezier(0.34, 1.56, 0.64, 1);
}
```

### 方式二：JavaScript API

```ts
import { fadeIn, slideInUp, Animator } from 'mk-motion'

// 快捷方法
await fadeIn(document.querySelector('.box'))
await slideInUp('.box', { duration: 600, easing: 'ease-out' })

// 链式控制
const anim = new Animator('.box')
await anim.animate('bounceIn', { duration: 500 })
anim.reset()
```

### 方式三：Web Animations API

```ts
import { Animator } from 'mk-motion'

const anim = new Animator('.box')
await anim.waa(
  [
    { transform: 'scale(1)', opacity: 1 },
    { transform: 'scale(1.2)', opacity: 0.8 },
    { transform: 'scale(1)', opacity: 1 },
  ],
  { duration: 300, iterations: 2 }
)
```

## 预设动画列表

| 动画 | 说明 |
|------|------|
| `fadeIn` / `fadeOut` | 淡入 / 淡出 |
| `slideInUp` / `slideInDown` / `slideInLeft` / `slideInRight` | 从各方向滑入 |
| `slideOutUp` / `slideOutDown` | 向上/下滑出 |
| `zoomIn` / `zoomOut` | 缩放进入 / 退出 |
| `bounceIn` / `bounceOut` | 弹跳进入 / 退出 |
| `flipInX` / `flipInY` | 3D 翻转进入 |
| `shake` | 左右摇晃 |
| `pulse` | 脉冲缩放 |
| `rotateIn` | 旋转进入 |

## API

### `new Animator(element)`

| 方法 | 说明 |
|------|------|
| `.animate(name, options)` | 播放 CSS 预设动画 |
| `.waa(keyframes, options)` | 使用 WAAPI 播放自定义关键帧 |
| `.stop()` | 停止当前动画 |
| `.reset()` | 移除所有动效类 |
| `.vars({ duration: '1s' })` | 设置 CSS 变量 |

### `AnimationOptions`

```ts
interface AnimationOptions {
  duration?: number      // 毫秒，默认 500
  easing?: string        // CSS easing，默认 'ease'
  delay?: number         // 延迟毫秒
  iterations?: number    // 次数，Infinity 为无限循环
  direction?: 'normal' | 'reverse' | 'alternate' | 'alternate-reverse'
  fill?: 'none' | 'forwards' | 'backwards' | 'both'
}
```

## 构建

```bash
npm install
npm run build
```

构建产物位于 `dist/`：
- `mk-motion.js` — ES Module
- `mk-motion.umd.cjs` — UMD（浏览器直接引用）
- `style.css` — 动画样式
- `index.d.ts` — 类型声明

## 许可证

MIT